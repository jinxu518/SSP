// console.log(__dirname);
require('./hello');

console.log(global.welcome);
console.log(globalThis.welcome);
console.log(welcome);