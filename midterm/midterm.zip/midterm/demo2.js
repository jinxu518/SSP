const obj = {};

console.log(obj.getName);