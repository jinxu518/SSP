var welcome = 'hi';

global.welcome = 'Hello';
globalThis.welcome = 'Nihao';